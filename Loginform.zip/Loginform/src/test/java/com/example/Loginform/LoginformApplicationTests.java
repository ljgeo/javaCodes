package com.example.Loginform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginformApplicationTests {

	@Test
	void contextLoads() {
	}

}
